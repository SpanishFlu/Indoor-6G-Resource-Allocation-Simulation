function T = build_class_rate_table(cfg, trace)
% BUILD_CLASS_RATE_TABLE  Reference "suitable" data rate per waveform class.
%   T = build_class_rate_table(cfg, trace)
%
%   Each of the 10 classes (see dataset/assign_class.m) is a
%   (numerology, guard_band) combination. This assigns each class a
%   representative achievable data rate using the SAME Shannon-capacity
%   formula as the scheduler in simulation/run_simulation.m:
%       rate_bps = BW_eff * log2(1 + SINR)
%   with SINR computed from the same link-budget parameters
%   (tx_power_dBm, noise_figure_dB) and a representative pathloss taken
%   as the median of the actual simulated trace.
%
%   The only thing that changes per class is the EFFECTIVE bandwidth:
%     - Numerology (subcarrier spacing) sets an inherent usable-RB
%       fraction of the channel: wider SCS numerologies waste
%       proportionally more spectrum on RB-edge guards (matches the
%       3GPP TS 38.101-1 trend of falling utilization ratio at higher
%       SCS for a fixed channel bandwidth).
%     - Guard-band category (Zero/Small/Large, from assign_guard_band.m)
%       adds an extra overhead on top, since "Large" means the slot is
%       more sensitive to inter-numerology interference and needs a
%       bigger protective guard.
%   A smaller effective bandwidth both lowers the Shannon BW term AND
%   lowers the thermal noise floor (N = -174dBm/Hz + NF, scaled by BW),
%   so the SINR/rate trade-off is handled consistently, not just bolted on.
%
%   Returns a MATLAB table with one row per class (1..10).

    % ----- Numerology -> subcarrier spacing & inherent usable-BW fraction -----
    %   Representative values following the 3GPP NR trend (TS 38.101-1
    %   Table 5.3.2-1): usable-RB fraction of channel BW falls as SCS grows.
    scs_khz          = [15, 30, 60, 120];        % indexed by numerology 1..4
    numerology_util  = [0.90, 0.86, 0.80, 0.72]; % indexed by numerology 1..4

    % ----- Guard-band category -> extra overhead fraction -----
    guard_util = struct('Zero', 1.00, 'Small', 0.95, 'Large', 0.90);

    % ----- Class 1..10 definitions (must match dataset/assign_class.m) -----
    class_defs = { ...
        1, 4, 'Zero';  2, 4, 'Small';  3, 4, 'Large'; ...
        4, 3, 'Zero';  5, 3, 'Small';  6, 3, 'Large'; ...
        7, 2, 'Zero';  8, 2, 'Small';  9, 2, 'Large'; ...
        10, 1, 'Any' };   % NUM-1 collapses all guard bands into Class 10

    % ----- Representative link condition (same physics as the scheduler) -----
    pl_ref_dB  = median(trace.pl_dB(:));
    tx_power_W = 10^((cfg.tx_power_dBm - 30) / 10);
    signal_W   = tx_power_W * 10^(-pl_ref_dB / 10);

    N = size(class_defs, 1);
    class_id = zeros(N,1); numerology = zeros(N,1); scs_col = zeros(N,1);
    guard_band = strings(N,1); usable_frac = zeros(N,1);
    bw_eff_Hz = zeros(N,1); sinr_dB = zeros(N,1); rate_Mbps = zeros(N,1);

    for i = 1:N
        cid = class_defs{i,1};
        mu  = class_defs{i,2};
        gb  = class_defs{i,3};

        if strcmp(gb, 'Any')
            g_util = mean([guard_util.Zero, guard_util.Small, guard_util.Large]);
        else
            g_util = guard_util.(gb);
        end
        u_util = numerology_util(mu);
        frac   = u_util * g_util;
        bw_eff = cfg.bandwidth_Hz * frac;

        noise_dBm = -174 + 10*log10(bw_eff) + cfg.noise_figure_dB;
        noise_W   = 10^((noise_dBm - 30) / 10);
        sinr      = signal_W / max(noise_W, cfg.eps);
        rate_bps  = bw_eff * log2(1 + sinr);

        class_id(i)    = cid;
        numerology(i)  = mu;
        scs_col(i)     = scs_khz(mu);
        guard_band(i)  = gb;
        usable_frac(i) = frac;
        bw_eff_Hz(i)   = bw_eff;
        sinr_dB(i)     = 10*log10(sinr);
        rate_Mbps(i)   = rate_bps / 1e6;
    end

    T = table(class_id, numerology, scs_col, guard_band, usable_frac, ...
              bw_eff_Hz, sinr_dB, rate_Mbps, 'VariableNames', ...
              {'Class', 'Numerology', 'SCS_kHz', 'GuardBand', ...
               'UsableBWFrac', 'BW_eff_Hz', 'SINR_dB', 'Rate_Mbps'});

    T = sortrows(T, 'Class');
end
