function plot_pf_before_after(summary_pf_before, summary_pf_after, mean_bw_before_Hz, mean_bw_after_Hz)
% PLOT_PF_BEFORE_AFTER  Visual comparison of PF scheduler KPIs before/after
% class-aware (numerology + guard band) effective bandwidth.
%   plot_pf_before_after(summary_pf_before, summary_pf_after, ...
%                         mean_bw_before_Hz, mean_bw_after_Hz)

    figure('Name', 'PF Before vs After Classification', ...
           'Position', [100, 100, 1300, 700]);

    labels = {'Before', 'After'};

    % ---- Panel 1: mean effective bandwidth ----
    subplot(2, 3, 1);
    bar(categorical(labels), [mean_bw_before_Hz, mean_bw_after_Hz] / 1e6);
    title('Mean effective bandwidth');
    ylabel('MHz');
    grid on;

    % ---- Panel 2: served throughput ----
    subplot(2, 3, 2);
    bar(categorical(labels), [summary_pf_before.served_Mbps, summary_pf_after.served_Mbps]);
    title('PF served throughput');
    ylabel('Mbps');
    grid on;

    % ---- Panel 3: load ratio ----
    subplot(2, 3, 3);
    bar(categorical(labels), [summary_pf_before.load_ratio, summary_pf_after.load_ratio]);
    title('Load ratio (served / offered)');
    ylabel('Ratio');
    grid on;

    % ---- Panel 4: success rate per class ----
    subplot(2, 3, 4);
    x = 1:2;
    w = 0.35;
    embb_succ  = [summary_pf_before.embb_success,  summary_pf_after.embb_success];
    urllc_succ = [summary_pf_before.urllc_success, summary_pf_after.urllc_success];
    bar(x - w/2, embb_succ, w, 'DisplayName', 'eMBB'); hold on;
    bar(x + w/2, urllc_succ, w, 'DisplayName', 'URLLC');
    set(gca, 'XTick', x, 'XTickLabel', labels);
    ylim([0, 1.05]);
    title('Packet success rate');
    grid on;
    legend('Location', 'best');
    hold off;

    % ---- Panel 5: mean delay per class ----
    subplot(2, 3, 5);
    embb_delay  = [summary_pf_before.embb_delay_mean_ms,  summary_pf_after.embb_delay_mean_ms];
    urllc_delay = [summary_pf_before.urllc_delay_mean_ms, summary_pf_after.urllc_delay_mean_ms];
    bar(x - w/2, embb_delay, w, 'DisplayName', 'eMBB'); hold on;
    bar(x + w/2, urllc_delay, w, 'DisplayName', 'URLLC');
    set(gca, 'XTick', x, 'XTickLabel', labels);
    ylabel('ms');
    title('Mean delay');
    grid on;
    legend('Location', 'best');
    hold off;

    % ---- Panel 6: p95 delay per class ----
    subplot(2, 3, 6);
    embb_p95  = [summary_pf_before.embb_delay_p95_ms,  summary_pf_after.embb_delay_p95_ms];
    urllc_p95 = [summary_pf_before.urllc_delay_p95_ms, summary_pf_after.urllc_delay_p95_ms];
    bar(x - w/2, embb_p95, w, 'DisplayName', 'eMBB'); hold on;
    bar(x + w/2, urllc_p95, w, 'DisplayName', 'URLLC');
    set(gca, 'XTick', x, 'XTickLabel', labels);
    ylabel('ms');
    title('p95 delay');
    grid on;
    legend('Location', 'best');
    hold off;
end
