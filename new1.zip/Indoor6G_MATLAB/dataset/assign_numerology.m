function numerology = assign_numerology(n_eMBB, n_uRLLC, mean_doppler)
% ASSIGN_NUMEROLOGY  5G NR numerology selection based on service mix and Doppler.
%   numerology = assign_numerology(n_eMBB, n_uRLLC, mean_doppler)
%
%   eMBB/URLLC-only system (mMTC removed). Thresholds scaled for a
%   physically-derived N_users=20 user pool with service probabilities
%   P(eMBB)=1/3, P(URLLC)=2/3 (mirroring the dedicated 1 eMBB : 2 URLLC
%   robot split).
%
%   NUM-4 (120 kHz): URLLC-dominated cell or high Doppler + strong URLLC
%   NUM-3 ( 60 kHz): eMBB-dominated cell or moderate Doppler + strong eMBB
%   NUM-2 ( 30 kHz): low-Doppler, non-dominant mix (repurposed from the
%                    old mMTC-dominated tier now that mMTC is removed —
%                    covers quasi-static/low-mobility slots that aren't
%                    clearly eMBB- or URLLC-dominated)
%   NUM-1 ( 15 kHz): default / balanced traffic

    if n_uRLLC > 13 || (mean_doppler > 120 && n_uRLLC > 10)
        numerology = 4;
    elseif n_eMBB > 9 || (mean_doppler > 80 && n_eMBB > 7)
        numerology = 3;
    elseif mean_doppler < 60 && n_uRLLC <= 10 && n_eMBB <= 7
        numerology = 2;
    else
        numerology = 1;
    end
end
